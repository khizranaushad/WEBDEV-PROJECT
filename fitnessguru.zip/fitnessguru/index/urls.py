from django.urls import path
from index import views

urlpatterns = [
    path('',views.home,name='home'),
    
     path('about/',views.about,name='about'),
      path('contact/',views.contact,name='contact'),
       path('diet/',views.diet,name='diet'),
        path('dietician/',views.dietician,name='dietician'),
         path('exercise/',views.exercise,name='exercise'),
          path('userlogin/',views.userlogin,name='userlogin'),
           path('register/',views.register,name='register'),
           path('services/',views.services,name='services'),
            path('trainer/',views.trainer,name='trainer'),
             path('logoutUser/',views.logoutUser,name='logoutUser'),
            
]