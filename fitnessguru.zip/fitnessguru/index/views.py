from django.contrib import auth
from django.shortcuts import redirect, render
from django.urls import reverse
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib import messages
from .models import *
from django.core.mail import message, send_mail
from django.conf import settings
from django.core.mail import EmailMessage
from django.core.files import File

# Create your views here.
def home(request):
    return render(request,"fittness-club.html")
def about(request):
    return render(request,"about.html")
def contact(request):
    return render(request,"contact.html")
def diet(request):
    return render(request,"diet.html")
def dietician(request):
    return render(request,"dietician.html")
def exercise(request):
    return render(request,"exercise.html")
def services(request):
    return render(request,"services.html")
def trainer(request):
    return render(request,"trainer.html")

def register(request):
    if request.method == 'POST':
        context = {
            'username':request.POST.get('username'),
            'password':request.POST.get('Password'),
            'email':request.POST.get('Email'),
            'name':request.POST.get('Name')
        }
        obj = User.objects.create_user(
            first_name=context['name'],
            username = context['username'],
            password = context['password'],
            email = context['email'],
        )
        obj.save()
        return redirect("userlogin")
    return render(request,"register.html")
def userlogin(request):
    if request.method == 'POST':
        username=request.POST.get('username')
        password=request.POST.get('Password')
        user=auth.authenticate(username=username,password=password)
        if user is not None:
            auth.login(request,user)
            return redirect("/")
        else:
            messages.info(request,'Invalid credentials')
            return redirect("userlogin")

    return render(request,"login.html")

def logoutUser(request):
    logout(request)
    return redirect("/")